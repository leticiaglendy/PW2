<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

    <header> 
        
    </header>

    <section>
        <h1> Dados dos Produtos </h1>
    </section>

    <section>
        <form action="" method="post">
            <div>
                <label> Pesquisar produto por nome: </label>
                <input type="text" name="txPesqNome" />                
            </div>

            <div>
                <input type="submit" value="Enviar" />
            </div>
        </form>
    </section>

    <section>
        <form action="/produto" method="post">
            <?php echo csrf_field(); ?>

            <div>
                <label> Nome </label>
                <input type="text" name="txNome" />
            </div>

            <div>
                <label> Quantidade </label>
                <input type="text" name="txQuantidade" />
            </div>

            <div>
                <label> Descrição </label>
                <input type="text" name="txDescricao" />
            </div>

            <div>
                <label> Valor </label>
                <input type="text" name="txValor" />
            </div>

            <div>
                <label> Data de Cadastro </label>
                <input type="text" name="txCadastro" />
            </div>

            <div>
                <input type="submit" value="Enviar" />
            </div>
        </form>
    </section>

    <section>
        <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nome Produto</th>
                        <th scope="col">Quantidade</th>
                        <th scope="col">Descrição</th>
                        <th scope="col">Valor</th>
                        <th scope="col">Data de Cadastro</th>
                    </tr>
                </thead>
            <tbody>
                <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($p->id_produto); ?> </th>
                        <td> <?php echo e($p->nome_produto); ?> </td>
                        <td> <?php echo e($p->quantidade); ?> </td>
                        <td> <?php echo e($p->descricao); ?> </td>
                        <td> <?php echo e($p->valor); ?> </td>
                        <td> <?php echo e($p->data_cadastro); ?> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
            </tbody>
        </table>
    </section>


    <footer>

    </footer>
    
</body>
</html><?php /**PATH C:\Users\Lab 06-Micro 10\Desktop\PWII\aula15\laravel\aula\resources\views/produto.blade.php ENDPATH**/ ?>