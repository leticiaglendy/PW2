<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

    <header> 
        
    </header>

    <section>
        <h1> Dados dos Contatos </h1>
    </section>

    <section>
        <form action="" method="post">
            <div>
                <label> Pesquisar contato por nome: </label>
                <input type="text" name="txPesqNome" />                
            </div>

            <div>
                <input type="submit" value="Enviar" />
            </div>
        </form>
    </section>

    <section>
        <form action="/contato" method="post">
            <?php echo csrf_field(); ?>

            <div>
                <label> Nome </label>
                <input type="text" name="txNome" />
            </div>

            <div>
                <label> E-mail </label>
                <input type="text" name="txEmail" />
            </div>

            <div>
                <label> Telefone </label>
                <input type="text" name="txTelefone" />
            </div>

            <div>
                <input type="submit" value="Enviar" />
            </div>

        </form>
    </section>

    <section>
        <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nome</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Telefone</th>
                    </tr>
                </thead>
            <tbody>
                <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"> <?php echo e($ct->id_contato); ?> </th>
                    <td> <?php echo e($ct->nome); ?> </td>
                    <td> <?php echo e($ct->email); ?> </td>
                    <td> <?php echo e($ct->telefone); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
            </tbody>
        </table>
    </section>

    <footer>

    </footer>
    
</body>
</html><?php /**PATH C:\laravel\aula\resources\views/contato.blade.php ENDPATH**/ ?>